/* Copyright 2020
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// Sendstring lookup tables for Canadian Multilingual layouts

#pragma once

#include "keymap_canadian_multilingual.h"
#include "quantum.h"

// clang-format off

const uint8_t ascii_to_shift_lut[16] PROGMEM = {
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),

    KCLUT_ENTRY(0, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 1, 0, 0, 0, 0, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 1, 1, 1, 1, 1),
    KCLUT_ENTRY(1, 1, 1, 0, 1, 0, 0, 1),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0)
};

const uint8_t ascii_to_altgr_lut[16] PROGMEM = {
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),

    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 1, 0, 1, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 1, 0, 1, 0, 0),
    KCLUT_ENTRY(1, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 0, 0, 0, 0, 0),
    KCLUT_ENTRY(0, 0, 0, 1, 1, 1, 1, 0)
};

const uint8_t ascii_to_keycode_lut[128] PROGMEM = {
    // NUL   SOH      STX      ETX      EOT      ENQ      ACK      BEL
    XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // BS    TAB      LF       VT       FF       CR       SO       SI
    KC_BSPC, KC_TAB,  KC_ENT,  XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // DLE   DC1      DC2      DC3      DC4      NAK      SYN      ETB
    XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,
    // CAN   EM       SUB      ESC      FS       GS       RS       US
    XXXXXXX, XXXXXXX, XXXXXXX, KC_ESC,  XXXXXXX, XXXXXXX, XXXXXXX, XXXXXXX,

    //       !        "        #        $        %        &        '
    KC_SPC,  CA_1,    CA_DOT,  CA_3,    CA_4,    CA_5,    CA_7,    CA_COMM,
    // (     )        *        +        ,        -        .        /
    CA_9,    CA_0,    CA_8,    CA_EQL,  CA_COMM, CA_MINS, CA_DOT,  CA_SLSH,
    // 0     1        2        3        4        5        6        7
    CA_0,    CA_1,    CA_2,    CA_3,    CA_4,    CA_5,    CA_6,    CA_7,
    // 8     9        :        ;        <        =        >        ?
    CA_8,    CA_9,    CA_SCLN, CA_SCLN, CA_DOT,  CA_EQL,  CA_COMM, CA_6,
    // @     A        B        C        D        E        F        G
    CA_2,    CA_A,    CA_B,    CA_C,    CA_D,    CA_E,    CA_F,    CA_G,
    // H     I        J        K        L        M        N        O
    CA_H,    CA_I,    CA_J,    CA_K,    CA_L,    CA_M,    CA_N,    CA_O,
    // P     Q        R        S        T        U        V        W
    CA_P,    CA_Q,    CA_R,    CA_S,    CA_T,    CA_U,    CA_V,    CA_W,
    // X     Y        Z        [        \        ]        ^        _
    CA_X,    CA_Y,    CA_Z,    CA_9,    CA_SLSH, CA_0,    CA_CIRC, CA_MINS,
    // `     a        b        c        d        e        f        g
    CA_CIRC, CA_A,    CA_B,    CA_C,    CA_D,    CA_E,    CA_F,    CA_G,
    // h     i        j        k        l        m        n        o
    CA_H,    CA_I,    CA_J,    CA_K,    CA_L,    CA_M,    CA_N,    CA_O,
    // p     q        r        s        t        u        v        w
    CA_P,    CA_Q,    CA_R,    CA_S,    CA_T,    CA_U,    CA_V,    CA_W,
    // x     y        z        {        |        }        ~        DEL
    CA_X,    CA_Y,    CA_Z,    CA_7,    CA_SLSH, CA_8,    CA_CCED, KC_DEL
};
